class News(object):
    def __init__(self, title, linkurl, message):
        self.title = title
        self.url = linkurl
        self.message = message
